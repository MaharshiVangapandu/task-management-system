package com.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.task.entity.Task;
import com.task.service.TaskService;
@CrossOrigin("*")
@RestController
@RequestMapping("/tasks")
public class TaskController {
	
	@Autowired
	private TaskService taskService;	
	
	@PostMapping("/createTask")
	public ResponseEntity<Task> createTask(@RequestBody Task task){
		return ResponseEntity.ok(taskService.creaTask(task));
	}
	@GetMapping("/getAllTasks")
	public ResponseEntity<List<Task>> getAllTasks(){
		return ResponseEntity.ok(taskService.getAllTasks());
	}
	@GetMapping("/getTaskById/{id}")
	public ResponseEntity<Task> getTaskById(@PathVariable Long id){
		return ResponseEntity.ok(taskService.getTaskById(id));
	}
	
	@DeleteMapping("/deleteTask/{id}")
	public ResponseEntity<String> deleteTask(@PathVariable Long id)
	{
		taskService.deleteTask(id);
		return ResponseEntity.ok("Task Deleted");
	}
	
	@PutMapping("/updateTask/{id}")
	public ResponseEntity<Task>updateTask(@PathVariable Long id ,@RequestBody Task taskDetails)
	{
		return ResponseEntity.ok(taskService.updateTask(id, taskDetails));
	}
	

}
