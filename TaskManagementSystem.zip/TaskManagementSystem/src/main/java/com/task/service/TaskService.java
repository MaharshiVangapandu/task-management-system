package com.task.service;

import java.util.List;

import com.task.entity.Task;

public interface TaskService {
	
	Task creaTask(Task task);
	List<Task> getAllTasks();
    Task getTaskById(Long id);
    Task updateTask(Long id, Task taskDetails);
    void deleteTask(Long id);

}
